# 轻松搞定表白女朋友APP

## 背景(Backgroud):
本软件的主要目的是用来表白女朋友，让女朋友开心，欢迎大家修改做出更好的效果，同时也十分欢迎大家star和提问(issues)，github开源库链接是：
https://github.com/Geeksongs/ExpressLove

An Android software used to express love to his girlfriend, currently there are fewer love software based on the Android platform on the Internet, so I open source of it. It mainly integrates Tencent X5 kernel, web and Android native mixed development. Software background dynamics can be changed at any time, supporting high customization and secondary development. Welcome all technical colleagues to download.

## 软件的效果如下(Demo Video):

![image](https://github.com/Geeksongs/ExpressLove/blob/master/yanshi.gif)

