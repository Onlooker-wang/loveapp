package su.levenetc.android.textsurface.contants;

/**
 * Created by Eugene Levenetc.
 */
public class Fit {
	public static int WIDTH = 2;
	public static int HEIGTH = 4;
}
