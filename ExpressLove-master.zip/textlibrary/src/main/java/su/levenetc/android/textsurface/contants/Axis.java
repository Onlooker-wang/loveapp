package su.levenetc.android.textsurface.contants;

/**
 * Created by Eugene Levenetc.
 */
public class Axis {
	public static final int X = 1;
	public static final int Y = 2;
	public static final int Z = 4;
}
