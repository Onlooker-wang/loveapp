package su.levenetc.android.textsurface.interfaces;

/**
 * Created by Eugene Levenetc.
 */
public interface IEndListener {
	void onAnimationEnd(ISurfaceAnimation animation);
}