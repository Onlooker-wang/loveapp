package su.levenetc.android.textsurface.contants;

/**
 * Created by Eugene Levenetc.
 */
public class Align {
	public static int RIGHT_OF = 2;
	public static int LEFT_OF = 4;
	public static int TOP_OF = 16;
	public static int BOTTOM_OF = 32;
	public static int CENTER_OF = 64;
	public static int SURFACE_CENTER = 128;
}
