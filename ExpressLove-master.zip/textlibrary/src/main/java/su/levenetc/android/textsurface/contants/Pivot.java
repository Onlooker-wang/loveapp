package su.levenetc.android.textsurface.contants;

/**
 * Created by Eugene Levenetc.
 */
public class Pivot {
	public static final int TOP = 1;
	public static final int BOTTOM = 2;
	public static final int LEFT = 4;
	public static final int RIGHT = 16;
	public static final int CENTER = 32;
}
