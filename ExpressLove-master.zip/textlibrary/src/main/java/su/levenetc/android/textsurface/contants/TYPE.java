package su.levenetc.android.textsurface.contants;

/**
 * Created by Eugene Levenetc.
 */
public enum TYPE {
	SEQUENTIAL, PARALLEL
}
