package su.levenetc.android.textsurface.contants;

/**
 * Created by Eugene Levenetc.
 */
public class Direction {
	public static int CLOCK = 1;
	public static int COUNTER_CLOCK = 2;
	public static int IN = 4;
	public static int OUT = 16;
}
